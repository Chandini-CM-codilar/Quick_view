<?php  
/**  * @category Codiar 
  * @package Codiar_QuickView  
  * @author Your Name <xxx@Codiar.com>  
  * @copyright www.Codiar.com  
  */ 
   \Magento\Framework\Component\ComponentRegistrar::register(  \Magento\Framework\Component\ComponentRegistrar::MODULE,  'Codiar_QuickView',  __DIR__  );