const targetDiv = document.getElementsByClassName("showcart");
const btn = document.getElementById("product-addtocart-button");
btn.onclick = function () {
  if (targetDiv.style.display !== "none") {
    targetDiv.style.display = "none";
  } else {
    targetDiv.style.display = "block";
  }
};
